package com.example.invoice.controller;

import com.example.invoice.entity.InvoiceEntity;
import com.example.invoice.service.InvoiceService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
public class InvoiceController {
    @Autowired
    private InvoiceService invoiceService;

    @RequestMapping(value = "/invoices", method = RequestMethod.GET)
    public ResponseEntity<List<InvoiceEntity>> getAllInvoice(){
//        return ResponseEntity.ok().body(invoiceService.getAllInvoice());
        return new ResponseEntity<List<InvoiceEntity>>(invoiceService.getAllInvoice(), HttpStatus.OK);
    }

    @RequestMapping(value = "/invoices/{id}", method = RequestMethod.GET)
    public ResponseEntity<InvoiceEntity> getInvoiceById(@PathVariable long id){
        return ResponseEntity.ok().body(invoiceService.getInvoiceById(id));
    }

    @RequestMapping(value = "/invoices", method = RequestMethod.POST)
    public ResponseEntity<InvoiceEntity> createInvoice(@RequestBody InvoiceEntity invoiceEntity){
        return ResponseEntity.ok().body(this.invoiceService.createInVoice(invoiceEntity));
    }

    @RequestMapping(value = "/invoices/{id}", method = RequestMethod.PUT)
    public ResponseEntity<InvoiceEntity> updateInvoice(@PathVariable long id, @RequestBody InvoiceEntity invoiceEntity){
        invoiceEntity.setId(id);
        return ResponseEntity.ok().body(this.invoiceService.updateInvoice(invoiceEntity));
    }

    @RequestMapping(value = "/invoices/{id}", method = RequestMethod.DELETE)
    public HttpStatus deleteInvoice(@PathVariable long id){
        this.invoiceService.deleteInvoice(id);
        return HttpStatus.OK;
    }
}
